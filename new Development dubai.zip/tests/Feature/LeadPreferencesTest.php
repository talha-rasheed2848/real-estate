<?php

namespace Tests\Feature;

use Tests\TestCase;

class LeadPreferencesTest extends TestCase
{
    public function test_home_form_includes_the_requested_locations_and_bedroom_options(): void
    {
        $response = $this->get('/');

        $response->assertOk();
        $response->assertSee('Tilal Al Ghaf');
        $response->assertSee('Emaar Beachfront');
        $response->assertSee('DAMAC Islands');
        $response->assertSee('Dubai Investment Park (DIP)');
        $response->assertSee('Dubai Land Residences');
        $response->assertSee('Dubai Science Park');
        $response->assertSee('Motor City');
        $response->assertSee('JVT');
        $response->assertSee('Meydan');
        $response->assertSee('Town Square');
        $response->assertSee('Sobha Hartland');
        $response->assertSee('Al Furjan');
        $response->assertSee('Palm Jebel Ali');
        $response->assertSee('Studio');
        $response->assertSee('1 Bedroom');
        $response->assertSee('2 Bedroom');
        $response->assertSee('3 Bedroom');
        $response->assertSee('4+ Bedrooms');
    }

    public function test_lead_rejects_bedroom_options_outside_the_form_choices(): void
    {
        $response = $this->from('/')->post('/lead', [
            'name' => 'Test Client',
            'email' => 'client@example.com',
            'bedrooms' => ['Penthouse'],
        ]);

        $response->assertRedirect('/');
        $response->assertSessionHasErrors('bedrooms.0');
    }
}
