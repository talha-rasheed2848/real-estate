<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title ?? 'New Developments Dubai'); ?></title>
    <meta name="description" content="<?php echo e($description ?? 'Luxury Dubai presale advisory with daily inventory access, VIP reports, and guaranteed cashback rewards.'); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Cormorant+Garamond:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body class="theme-light <?php echo e($bodyClass ?? ''); ?>">
<header class="site-header">
    <div class="container nav-wrap">
        <a href="<?php echo e(route('home')); ?>" class="brand" aria-label="New Developments Dubai homepage">
            <span class="brand-mark" aria-hidden="true"><img src="<?php echo e(asset('images/logo-nd.png')); ?>" alt=""></span>
            <span class="brand-text"><span>NEW DEVELOPMENTS</span><span class="brand-sub">DUBAI</span></span>
        </a>
        <nav class="main-nav" aria-label="Main navigation">
            <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">Home</a>
            <a href="<?php echo e(route('about')); ?>" class="<?php echo e(request()->routeIs('about') ? 'active' : ''); ?>">About</a>
            <a href="<?php echo e(route('vip')); ?>" class="<?php echo e(request()->routeIs('vip') ? 'active' : ''); ?>">VIP Cashback</a>
            <a href="<?php echo e(route('contact')); ?>" class="<?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>">Contact</a>
        </nav>
        <div class="nav-actions">
            <button class="menu-toggle" type="button" aria-label="Open navigation menu" aria-expanded="false"><span></span><span></span><span></span></button>
            <button class="theme-toggle" type="button" aria-label="Switch to dark mode" aria-pressed="false">
                <span class="theme-toggle-thumb" aria-hidden="true"></span>
                <span class="theme-toggle-icon theme-toggle-sun" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3.5"></circle><path d="M12 2v2.2m0 15.6V22M4.93 4.93l1.56 1.56m11.02 11.02 1.56 1.56M2 12h2.2m15.6 0H22M4.93 19.07l1.56-1.56M17.51 6.49l1.56-1.56"></path></svg></span>
                <span class="theme-toggle-icon theme-toggle-moon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none"><path d="M20.2 15.1A8.6 8.6 0 0 1 8.9 3.8 8.7 8.7 0 1 0 20.2 15.1Z"></path></svg></span>
            </button>
            <a href="<?php echo e(route('contact')); ?>" class="primary-btn">Join The VIP</a>
        </div>
    </div>
</header>

<?php echo $__env->yieldContent('content'); ?>

<footer class="site-footer">
    <div class="container footer-wrap">
        <div class="footer-brand-wrap">
            <img src="<?php echo e(asset('images/logo-nd.png')); ?>" style="width: 70px;" alt="New Developments Dubai logo">
            <div><p class="footer-brand">New Developments Dubai</p><p>Luxury presale advisory for discerning buyers.</p></div>
        </div>
        <div class="footer-links"><a href="<?php echo e(route('home')); ?>">Home</a><a href="<?php echo e(route('about')); ?>">About</a><a href="<?php echo e(route('vip')); ?>">VIP Cashback</a><a href="<?php echo e(route('contact')); ?>">Contact</a></div>
        <div class="footer-meta">
            <p><svg class="contact-icon" viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></svg><a href="mailto:info@newdevelopmentsdubai.com">info@newdevelopmentsdubai.com</a></p>
            <p><svg class="contact-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11.5a8 8 0 0 1-11.8 7L4 20l1.5-4.1A8 8 0 1 1 20 11.5Z"/><path d="M8.5 8.5c.2 1.8 2.2 4 4 4.8l1.3-1.1 1.7.8c.3.2.4.6.2.9-.4.7-1.2 1.1-2 1-3.6-.6-6.5-3.5-7.1-7.1-.1-.8.3-1.6 1-2 .3-.2.7-.1.9.2l.8 1.7-1.1 1.3Z"/></svg><a href="https://wa.me/971525206930" target="_blank" rel="noopener">+971 525206930</a></p>
            <p><svg class="contact-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></svg><a href="https://maps.google.com/?q=Happiness+Street,+Zaa'beel+Second,+DIFC,+Dubai,+UAE" target="_blank" rel="noopener">Happiness Street, Zaa'beel Second, DIFC, Dubai, UAE</a></p>
        </div>
    </div>
</footer>
<a class="floating-whatsapp" href="https://wa.me/971525206930" target="_blank" rel="noopener" aria-label="Chat with us on WhatsApp"><svg class="whatsapp-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11.5a8 8 0 0 1-11.8 7L4 20l1.5-4.1A8 8 0 1 1 20 11.5Z"/><path d="M8.5 8.5c.2 1.8 2.2 4 4 4.8l1.3-1.1 1.7.8c.3.2.4.6.2.9-.4.7-1.2 1.1-2 1-3.6-.6-6.5-3.5-7.1-7.1-.1-.8.3-1.6 1-2 .3-.2.7-.1.9.2l.8 1.7-1.1 1.3Z"/></svg></a>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php if(session('success')): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Thank you!',
        text: <?php echo json_encode(session('success'), 15, 512) ?>,
        confirmButtonText: 'Perfect',
        confirmButtonColor: '#b7893f',
        background: '#fffaf4',
        color: '#171511',
    });
</script>
<?php elseif($errors->any()): ?>
<script>
    Swal.fire({
        icon: 'warning',
        title: 'Please check your details',
        text: <?php echo json_encode($errors->first(), 15, 512) ?>,
        confirmButtonText: 'Review form',
        confirmButtonColor: '#b7893f',
        background: '#fffaf4',
        color: '#171511',
    });
</script>
<?php endif; ?>
</body>
</html><?php /**PATH C:\wamp64\www\new_real_estate_polished (1)\resources\views/layouts/app.blade.php ENDPATH**/ ?>