
<?php $__env->startSection('content'); ?>
<?php
    $propertyTypes = ['Apartment', 'Villa', 'Beachfront Villa', 'Townhouse'];
    $locations = [
        'Downtown Dubai', 'Business Bay', 'Dubai Marina', 'Palm Jumeirah', 'Dubai Hills', 'JVC',
        'Dubai Creek Harbour', 'Emirates Hills', 'Bluewaters', 'JBR', 'Dubai Water Canal', 'Al Barsha',
        'MBR City', 'Arabian Ranches', 'Dubai South', 'The Springs', 'Tilal Al Ghaf', 'Emaar Beachfront',
        'DAMAC Islands', 'Dubai Investment Park (DIP)', 'Dubai Land Residences', 'Dubai Science Park',
        'Motor City', 'JVT', 'Meydan', 'Town Square', 'Sobha Hartland', 'Al Furjan', 'Palm Jebel Ali',
    ];
    $bedroomOptions = ['Studio', '1 Bedroom', '2 Bedroom', '3 Bedroom', '4+ Bedrooms'];
    $priceRanges = ['Under 1M AED', '1M - 2M AED', '2M - 3M AED', '3M - 5M AED', '5M - 10M AED', '10M+ AED'];
    $developers = ['Emaar', 'DAMAC', 'Nakheel', 'Sobha', 'Meraas', 'Dubai Properties', 'Binghatti', 'Azizi', 'Danube', 'Omniyat', 'Aldar', 'Select Group'];
    $purchaseTimings = ['Within 3 Months', '3 - 6 Months', '6+ Months'];
?>
<main>
    <section class="hero-panel">
        <div class="hero-bg-wrap" aria-hidden="true">
            <div class="hero-bg hero-layer-a"></div>
            <div class="hero-bg hero-layer-b"></div>
        </div>
        <div class="container hero-shell">
            <div class="hero-content">
                <p class="eyebrow">Exclusive access to Dubai's most sought-after presales</p>
                <h1>Dubai's Most Exclusive Presales - Delivered to You</h1>
                <p class="subheadline">Access daily updated inventory and earn 1% cashback when you purchase through us.
                </p>
                <div class="trust-row" aria-label="Trust list"><span>Exclusive Access</span><span>Cashback
                        Guaranteed</span><span>Custom Tailored Reports</span></div>
                <div class="hero-actions"><a href="#lead-form" class="primary-btn">Sign Up for VIP Access</a>
                    <p class="fine-print">Get your free curated PDF report</p>
                </div>
            </div>
            <div class="slide-indicators" aria-label="Hero image indicators"><span
                    class="active"></span><span></span><span></span><span></span></div>
        </div>
    </section>
    <section class="lead-section" id="lead-form">
        <div class="container lead-shell">
            <div class="section-intro">
                <p class="section-label">Free tailored report</p>
                <h2>Tell us what you're looking for</h2>
            </div>
            <form class="lead-form" method="POST" action="<?php echo e(route('lead.store')); ?>"><?php echo csrf_field(); ?>
                <div class="selection-group"><label class="group-title">Property Type</label>
                    <div class="choice-grid"><?php $__currentLoopData = $propertyTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label class="choice-item"><input type="checkbox" name="property_type[]"
                                value="<?php echo e($option); ?>"> <?php echo e($option); ?></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                </div>
                <div class="selection-group"><label class="group-title">Location</label>
                    <div class="choice-grid area-grid"><?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label class="choice-item"><input
                                type="checkbox" name="location[]"
                                value="<?php echo e($option); ?>"> <?php echo e($option); ?></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                </div>
                <div class="selection-group"><label class="group-title">Bedrooms</label>
                    <div class="choice-grid"><?php $__currentLoopData = $bedroomOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label class="choice-item"><input type="checkbox" name="bedrooms[]"
                                value="<?php echo e($option); ?>"> <?php echo e($option); ?></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                </div>
                <div class="selection-group"><label class="group-title">Price Range</label>
                    <div class="choice-grid"><?php $__currentLoopData = $priceRanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label class="choice-item"><input type="checkbox"
                                name="price_range[]" value="<?php echo e($option); ?>"> <?php echo e($option); ?></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                </div>
                <div class="selection-group"><label class="group-title">Developers</label>
                    <div class="choice-grid developer-grid"><?php $__currentLoopData = $developers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label class="choice-item"><input type="checkbox" name="developers[]"
                                value="<?php echo e($option); ?>"> <?php echo e($option); ?></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                </div>
                <div class="selection-group"><label class="group-title">Purchase Timing</label>
                    <div class="choice-grid"><?php $__currentLoopData = $purchaseTimings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label class="choice-item"><input type="checkbox" name="purchase_timing[]"
                                value="<?php echo e($option); ?>"> <?php echo e($option); ?></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                </div>
                <div class="contact-row">
                    <div class="field-wrap"><label for="name">Name</label><input id="name" name="name" type="text"
                            placeholder="Your full name" required></div>
                    <div class="field-wrap"><label for="email">Email</label><input id="email" name="email" type="email"
                            placeholder="Your email" required></div>
                </div>
                <div class="field-wrap"><label for="comments">Comments</label><textarea id="comments" name="comments"
                        rows="4" placeholder="Tell us anything else that would help us curate your report"></textarea>
                </div><button type="submit" class="submit-btn">Get My Free PDF Report</button>
            </form>
        </div>
    </section>
    <?php echo $__env->make('partials.projects', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'New Developments Dubai | Luxury Presales', 'bodyClass' => 'home-page'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\new_real_estate_polished (1)\resources\views/home.blade.php ENDPATH**/ ?>