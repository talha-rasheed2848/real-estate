@extends('layouts.app', ['title' => 'Contact | New Developments Dubai'])
@section('content')
<main class="container page-shell">
    <section class="page-banner page-banner-contact">
        <div class="page-banner-inner">
            <p class="eyebrow">Let's Connect</p>
            <h1>Let's Connect</h1>
        </div>
    </section>
    <div class="page-grid">
        <section class="contact-card">
            <h2>Send us a message</h2>
            <p>We would love to learn about your buying goals and share tailored opportunities in Dubai.</p>
            <form class="contact-form" method="POST" action="{{ route('contact.store') }}">@csrf<input name="name"
                    type="text" placeholder="Name" aria-label="Name" required><input name="email" type="email"
                    placeholder="Email" aria-label="Email" required><textarea name="message" rows="5"
                    placeholder="Message" aria-label="Message" required></textarea><button type="submit"
                    class="submit-btn">Send Message</button></form>
        </section>
        <aside class="contact-card">
            <h2>Contact Details</h2>
            <ul class="contact-list">
                <li><span class="contact-icon">&#9742;</span><a href="https://wa.me/971525206930" target="_blank"
                        rel="noopener">+971 525206930</a></li>
                <li><span class="contact-icon">&#9993;</span><a
                        href="mailto:info@newdevelopmentsdubai.com">info@newdevelopmentsdubai.com</a></li>
                <li><span class="contact-icon">&#9679;</span><a
                        href="https://maps.google.com/?q=Happiness+Street,+Zaa'beel+Second,+DIFC,+Dubai,+UAE"
                        target="_blank" rel="noopener">Happiness Street, Zaa'beel Second, DIFC, Dubai, UAE</a></li>
            </ul>
        </aside>
    </div>
    <section class="map-section" style="display:none;" aria-labelledby="map-title">
        <div class="map-heading">
            <div>
                <p class="section-label">Visit us</p>
                <h2 id="map-title">Find us in DIFC</h2>
            </div><a class="map-address"
                href="https://maps.google.com/?q=Happiness+Street,+Zaa'beel+Second,+DIFC,+Dubai,+UAE" target="_blank"
                rel="noopener">Happiness Street, Zaa'beel Second, DIFC, Dubai, UAE</a>
        </div>
        <div class="map-frame"><iframe title="Map showing Happiness Street, Zaa'beel Second, DIFC, Dubai, UAE"
                src="https://www.google.com/maps?q=Happiness+Street,+Zaa%27beel+Second,+DIFC,+Dubai,+UAE&output=embed"
                loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe></div>
    </section>@include('partials.projects')
</main>
@endsection