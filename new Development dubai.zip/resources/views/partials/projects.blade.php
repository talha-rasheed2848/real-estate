<section class="showcase-section page-showcase">
    <div class="container">
        <div class="section-intro compact"><p class="section-label">Featured projects</p><h2>Curated presale opportunities</h2></div>
        <div class="project-slider" aria-label="Curated property slider">
            <div class="project-track">
                @foreach ([['Downtown', 'AED 2.4M', 'Skyline Residences', 'Luxury apartments with panoramic city views and promising rental demand.', 'image-one'], ['Palm Jumeirah', 'AED 7.8M', 'Waterfront Villas', 'Private coastal living with resort-style amenities and exceptional lifestyle value.', 'image-two'], ['Dubai Hills', 'AED 4.1M', 'Signature Penthouse', 'Elegant double-height living designed for elevated urban experiences.', 'image-three'], ['Dubai Creek Harbour', 'AED 1.9M', 'Creekside Collection', 'Refined waterfront apartments moments from the new Dubai Creek skyline.', 'image-four'], ['Business Bay', 'AED 1.6M', 'Canal House', 'Design-led residences positioned for city living beside the Dubai Water Canal.', 'image-five'], ['Jumeirah', 'AED 3.6M', 'Jumeirah Gardens', 'Quiet, contemporary homes with generous layouts and elevated finishing.', 'image-six']] as $index => $project)
                    <article class="project-card {{ $index === 0 ? 'active' : '' }}"><div class="project-image {{ $project[4] }}"></div><div class="project-copy"><div class="meta-row"><span>{{ $project[0] }}</span><span>From {{ $project[1] }}</span></div><h3>{{ $project[2] }}</h3><p>{{ $project[3] }}</p></div></article>
                @endforeach
            </div>
            <div class="slider-dots" aria-label="Slider controls">@foreach (range(1, 6) as $dot)<span class="dot {{ $dot === 1 ? 'active' : '' }}"></span>@endforeach</div>
        </div>
    </div>
</section>