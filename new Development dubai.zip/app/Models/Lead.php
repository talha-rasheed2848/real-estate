<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Lead extends Model
{
    use HasFactory;

    protected $fillable = [
        'name', 'email', 'property_type', 'location', 'bedrooms', 'price_range',
        'developers', 'purchase_timing', 'comments', 'status',
    ];

    protected $casts = [
        'property_type' => 'array',
        'location' => 'array',
        'bedrooms' => 'array',
        'price_range' => 'array',
        'developers' => 'array',
        'purchase_timing' => 'array',
    ];
}
