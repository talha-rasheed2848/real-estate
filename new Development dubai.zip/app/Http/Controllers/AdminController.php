<?php

namespace App\Http\Controllers;

use App\Models\ContactMessage;
use App\Models\Lead;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    public function dashboard()
    {
        return view('admin.dashboard', [
            'leadCount' => Lead::count(),
            'messageCount' => ContactMessage::count(),
            'userCount' => User::count(),
            'newLeadCount' => Lead::where('status', 'new')->count(),
            'recentLeads' => Lead::latest()->take(5)->get(),
            'recentMessages' => ContactMessage::latest()->take(5)->get(),
        ]);
    }

    public function leads()
    {
        return view('admin.leads', ['leads' => Lead::latest()->paginate(12)]);
    }

    public function showLead(Lead $lead)
    {
        return view('admin.lead-show', ['lead' => $lead]);
    }

    public function messages()
    {
        return view('admin.messages', ['messages' => ContactMessage::latest()->paginate(12)]);
    }

    public function users()
    {
        return view('admin.users', ['users' => User::latest()->paginate(12)]);
    }

    public function settings()
    {
        return view('admin.settings', ['preferences' => auth()->user()->preferences ?? []]);
    }

    public function updateSettings(Request $request)
    {
        $data = $request->validate([
            'theme' => ['required', 'in:dark,light'],
            'accent' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'workspace_name' => ['required', 'string', 'max:40'],
            'compact_tables' => ['nullable', 'boolean'],
        ]);
        $data['compact_tables'] = $request->boolean('compact_tables');
        auth()->user()->update(['preferences' => $data]);

        return back()->with('admin_success', 'Workspace preferences saved.');
    }

    public function resetSettings()
    {
        auth()->user()->update([
            'preferences' => [
                'theme' => 'dark',
                'accent' => '#d6ae70',
                'workspace_name' => 'NEW DEVELOPMENTS',
                'compact_tables' => false,
            ],
        ]);

        return back()->with('admin_success', 'Workspace preferences reset to default.');
    }

    public function storeUser(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'email' => ['required', 'email', 'max:160', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8'],
            'is_admin' => ['nullable', 'boolean'],
        ]);
        $data['password'] = Hash::make($data['password']);
        $data['is_admin'] = $request->boolean('is_admin');
        User::create($data);

        return back()->with('admin_success', 'User account created successfully.');
    }

    public function updateLead(Request $request, Lead $lead)
    {
        $lead->update($request->validate(['status' => ['required', 'in:new,contacted,qualified,archived']]));
        return back()->with('admin_success', 'Lead status updated.');
    }

    public function updateMessage(Request $request, ContactMessage $contactMessage)
    {
        $contactMessage->update($request->validate(['status' => ['required', 'in:unread,read,replied,archived']]));
        return back()->with('admin_success', 'Message status updated.');
    }

    public function destroyUser(User $user)
    {
        abort_if($user->is(auth()->user()), 403, 'You cannot delete your own account.');
        $user->delete();
        return back()->with('admin_success', 'User account removed.');
    }
}
