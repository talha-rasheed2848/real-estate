const heroSlides = [
  "/images/hero1.webp",
  "/images/hero2.webp",
  "/images/hero3.jpg",
  "/images/hero.jpg",
];

const heroLayers = [
  document.querySelector(".hero-layer-a"),
  document.querySelector(".hero-layer-b"),
];
const indicators = document.querySelectorAll(".slide-indicators span");
const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

let slideIndex = 0;
let activeLayer = 0;

function updateHeroSlide() {
  if (!heroLayers[0] || !heroLayers[1]) return;

  const nextLayer = activeLayer === 0 ? 1 : 0;
  const layerEl = heroLayers[nextLayer];

  layerEl.style.backgroundImage = `url(${heroSlides[slideIndex]})`;

  // Reset zoom instantly on the incoming layer before it fades in.
  layerEl.style.transition = "none";
  layerEl.style.transform = "scale(1.04)";
  layerEl.getBoundingClientRect(); // force reflow

  requestAnimationFrame(() => {
    layerEl.style.transition = "";
    heroLayers[activeLayer].classList.remove("is-active");
    layerEl.classList.add("is-active");
    activeLayer = nextLayer;
  });

  if (indicators.length) {
    indicators.forEach((dot, idx) => {
      dot.classList.toggle("active", idx === slideIndex);
    });
  }

  slideIndex = (slideIndex + 1) % heroSlides.length;
}

if (heroLayers[0] && heroLayers[1]) {
  updateHeroSlide();
  setInterval(updateHeroSlide, 5000);
}

// Reveal sections and cards as they scroll into view.
const revealTargets = document.querySelectorAll(
  [
    ".lead-shell",
    ".section-intro",
    ".project-card",
    ".info-card",
    ".value-card",
    ".contact-card",
    ".cashback-box",
    ".about-story",
    ".map-heading",
    ".map-frame",
    ".page-banner-inner",
  ].join(", ")
);

if (revealTargets.length) {
  revealTargets.forEach((el) => el.classList.add("reveal"));

  if (prefersReducedMotion || !("IntersectionObserver" in window)) {
    revealTargets.forEach((el) => el.classList.add("is-visible"));
  } else {
    const revealObserver = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15, rootMargin: "0px 0px -60px 0px" }
    );

    revealTargets.forEach((el) => revealObserver.observe(el));
  }
}

document.querySelectorAll(".project-slider").forEach((slider) => {
  const track = slider.querySelector(".project-track");
  const cards = [...slider.querySelectorAll(".project-card")];
  const dots = [...slider.querySelectorAll(".dot")];
  if (!track || !cards.length) return;

  let propertyIndex = 0;

  const getVisibleCards = () => {
    if (window.innerWidth <= 560) return 1;
    if (window.innerWidth <= 820) return 2;
    return 3;
  };

  const updateSlider = (nextIndex = propertyIndex) => {
    const visibleCards = getVisibleCards();
    const maxIndex = Math.max(0, cards.length - visibleCards);
    propertyIndex = Math.min(Math.max(nextIndex, 0), maxIndex);
    const cardWidth = cards[0].getBoundingClientRect().width;
    const gap = parseFloat(getComputedStyle(track).gap) || 0;
    track.style.transform = `translateX(-${propertyIndex * (cardWidth + gap)}px)`;
    dots.forEach((dot, index) => {
      dot.hidden = index > maxIndex;
      dot.classList.toggle("active", index === propertyIndex);
    });
  };

  const previousButton = document.createElement("button");
  previousButton.className = "slider-arrow prev";
  previousButton.type = "button";
  previousButton.setAttribute("aria-label", "Previous featured project");
  previousButton.innerHTML = "&#8249;";

  const nextButton = document.createElement("button");
  nextButton.className = "slider-arrow next";
  nextButton.type = "button";
  nextButton.setAttribute("aria-label", "Next featured project");
  nextButton.innerHTML = "&#8250;";

  slider.append(previousButton, nextButton);
  previousButton.addEventListener("click", () => updateSlider(propertyIndex - 1));
  nextButton.addEventListener("click", () => updateSlider(propertyIndex + 1));
  dots.forEach((dot, index) => dot.addEventListener("click", () => updateSlider(index)));

  updateSlider();
  window.addEventListener("resize", () => updateSlider(propertyIndex));
  setInterval(() => {
    const maxIndex = Math.max(0, cards.length - getVisibleCards());
    updateSlider(propertyIndex >= maxIndex ? 0 : propertyIndex + 1);
  }, 5200);
});

const menuToggle = document.querySelector(".menu-toggle");
const mainNav = document.querySelector(".main-nav");

if (menuToggle && mainNav) {
  const closeMenu = () => {
    menuToggle.classList.remove("is-open");
    mainNav.classList.remove("is-open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Open navigation menu");
  };

  menuToggle.addEventListener("click", (event) => {
    event.stopPropagation();
    const isOpen = mainNav.classList.toggle("is-open");
    menuToggle.classList.toggle("is-open", isOpen);
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Close navigation menu" : "Open navigation menu");
  });

  mainNav.querySelectorAll("a").forEach((link) => link.addEventListener("click", closeMenu));
  document.addEventListener("click", (event) => {
    if (!mainNav.contains(event.target) && !menuToggle.contains(event.target)) closeMenu();
  });
  window.addEventListener("resize", () => {
    if (window.innerWidth > 980) closeMenu();
  });
}

const themeToggle = document.querySelector(".theme-toggle");

if (themeToggle) {
  const updateThemeToggle = (isLight) => {
    themeToggle.setAttribute("aria-pressed", String(!isLight));
    themeToggle.setAttribute("aria-label", `Switch to ${isLight ? "dark" : "light"} mode`);
  };

  updateThemeToggle(document.body.classList.contains("theme-light"));
  themeToggle.addEventListener("click", () => {
    const root = document.body;
    const isLight = root.classList.toggle("theme-light");
    root.classList.toggle("theme-dark", !isLight);
    updateThemeToggle(isLight);
  });
}

const propertyPrice = document.querySelector("#property-price");
const cashbackResult = document.querySelector("#cashback-result");

if (propertyPrice && cashbackResult) {
  const currencyFormatter = new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 2
  });

  propertyPrice.addEventListener("input", () => {
    const price = Number(propertyPrice.value.replace(/[^0-9.]/g, ""));
    const cashback = Number.isFinite(price) ? price * 0.01 : 0;
    cashbackResult.textContent = `Your cashback: AED ${currencyFormatter.format(cashback)}`;
  });
}
