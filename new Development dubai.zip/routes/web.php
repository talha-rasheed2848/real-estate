<?php

use App\Http\Controllers\AdminAuthController;
use App\Http\Controllers\AdminController;
use App\Models\ContactMessage;
use App\Models\Lead;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Validation\Rule;

Route::view('/', 'home')->name('home');
Route::view('/about', 'about')->name('about');
Route::view('/vip-cashback', 'vip')->name('vip');
Route::view('/contact', 'contact')->name('contact');

Route::post('/contact', function (Request $request) {
    $data = $request->validate([
        'name' => ['required', 'string', 'max:120'],
        'email' => ['required', 'email', 'max:160'],
        'message' => ['required', 'string', 'max:5000'],
    ]);
    ContactMessage::create($data);

    return back()->with('success', 'Thank you. We will be in touch shortly.');
})->name('contact.store');

Route::post('/lead', function (Request $request) {
    $data = $request->validate([
        'name' => ['required', 'string', 'max:120'],
        'email' => ['required', 'email', 'max:160'],
        'property_type' => ['nullable', 'array'],
        'location' => ['nullable', 'array'],
        'bedrooms' => ['nullable', 'array'],
        'bedrooms.*' => ['string', Rule::in(['Studio', '1 Bedroom', '2 Bedroom', '3 Bedroom', '4+ Bedrooms'])],
        'price_range' => ['nullable', 'array'],
        'developers' => ['nullable', 'array'],
        'purchase_timing' => ['nullable', 'array'],
        'comments' => ['nullable', 'string', 'max:5000'],
    ]);
    Lead::create($data);

    return back()->with('success', 'Your tailored report request has been received.');
})->name('lead.store');

Route::prefix('admin')->name('admin.')->group(function () {
    Route::middleware('guest')->group(function () {
        Route::get('/login', [AdminAuthController::class, 'create'])->name('login');
        Route::post('/login', [AdminAuthController::class, 'store'])->name('login.store');
    });

    Route::middleware(['auth', 'admin'])->group(function () {
        Route::get('/', [AdminController::class, 'dashboard'])->name('dashboard');
        Route::post('/logout', [AdminAuthController::class, 'destroy'])->name('logout');
        Route::get('/leads', [AdminController::class, 'leads'])->name('leads');
        Route::get('/leads/{lead}', [AdminController::class, 'showLead'])->name('leads.show');
        Route::patch('/leads/{lead}', [AdminController::class, 'updateLead'])->name('leads.update');
        Route::get('/messages', [AdminController::class, 'messages'])->name('messages');
        Route::patch('/messages/{contactMessage}', [AdminController::class, 'updateMessage'])->name('messages.update');
        Route::get('/users', [AdminController::class, 'users'])->name('users');
        Route::post('/users', [AdminController::class, 'storeUser'])->name('users.store');
        Route::delete('/users/{user}', [AdminController::class, 'destroyUser'])->name('users.destroy');
        Route::get('/settings', [AdminController::class, 'settings'])->name('settings');
        Route::patch('/settings', [AdminController::class, 'updateSettings'])->name('settings.update');
        Route::post('/settings/reset', [AdminController::class, 'resetSettings'])->name('settings.reset');
    });
});
